<?php
require_once("class/dbconfig.php");

		if($crud->logout() ){
			
		   header('location:index.html');
		}else{
                    $error = "Wrong username or password";
                }


?>
