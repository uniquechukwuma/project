<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Emp_record extends Model
{
    //
}
