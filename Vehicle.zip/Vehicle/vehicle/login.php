<?php
include 'class/pdo.php';
if(isset($_POST['login_btn'])){
$username = security($_POST['userid']);
$password = security($_POST['userpassword']);

require_once("class/dbconfig.php");

		if($crud->login($username,$password)==TRUE) {
			
		   header('location:account.php');
		}else{
                    $error = "Wrong username or password";
                }
//$select_accounts = select('newaccount')->where('username='."$username")->result(); 
//$select_accounts = select('newaccount')->where('username='.$username.'and password='.$password)->result(); 
//echo $select_accounts['username'];
}
include 'header.html';
?>

	<!-- banner -->
        <div class="banner inner-banner" style="background: url(images/login.jpg)no-repeat center center;">
		<div class="header-nav"><!-- header-three --> 	
			<nav class="navbar navbar-default">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						Menu 
					</button> 
				</div>
				<!-- top-nav -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
					
						<li><a href="index.html" class="active">Home</a></li>
						   
						<li><a href="register.php" class="scroll">Register</a></li>    
                        <li><a href="login.php" class="scroll">Login</a></li>	
						<li><a href="contact.html" class="scroll">Contact Us</a></li>
					 
					</ul> 
					<div class="clearfix"> </div>	
				</div>
			</nav>    
		</div>
		<!-- banner-text -->
		<!-- banner -->
	</div>	
	<!-- contact -->
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
				<h2 class="h3-w3l">Login</h2> 
			</div>
			<div class="contact_wthreerow agileits-w3layouts">
                            <div class="col-md-6 col-md-offset-3">
                                <form method="post" enctype="multipart/form-data">
                                    <div class="text-danger text-center"><?php if(isset($error)){echo $error;} ?></div>
                                    <div class="form-group">
                                        <label for="userid" class="font-weight-3 fine_text innerB">User Id: </label>
                                        <input type="text" class="form-control rounded-none" name="userid"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="userpassword" class="font-weight-3 fine_text innerB">User Password: </label>
                                        <input type="text" class="form-control rounded-none" name="userpassword"/>
                                    </div>
                                    <button type="submit" name="login_btn" class="btn btn-primary rounded-none center-block">Login</button>
                                </form>
                            </div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //contact --> 

<!--footer-->
<div class="agile-footer w3ls-section">
	<div class="container">
		<!--div class="col-md-7 list-footer">
		  <ul class="footer-nav">
				<li><a  href="index.html">Home</a></li>
				<li><a  href="about.html">About</a></li>
				<li><a  href="services.html">Services</a></li>
				<li><a href="gallery.html">Gallery</a></li>
				<li><a href="contact.html">Contact Us</a></li>
		  </ul>
		  <p>Vivamus sed porttitor felis. Pellentesque habitant morbi tristique senectus et netus et ctetur adipiscing elit. Cras rutrum iaculis</p>
		</div-->
		<div class="col-md-6 col-md-offset-3 text-center agileinfo-sub">
			<h6 style="margin-bottom: 10px">Click the link below to start the subscription service</h6>
			<button type="button" class="btn btn-primary" href="#" data-toggle="modal" data-target="#myModal1">subscribe</button>
		</div>
		<div class="clearfix"></div>
     </div>
</div>	 
<div class="w3_agile-copyright text-center">
    <p class="text-center">© 2017 Lottery Based Processing System</p>
</div>
<!--//footer-->	
	<!-- subscribe -->
	<div class="modal bnr-modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<img src="images/logo.png" alt="logo"/>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
					<p>Star Merchant email newsletter provides subscribers with helpful articles on important issues in the banking industry, as well as news about events and more! To sign up for the newsletter, fill the below form.</p>
					<form class=" wthree-subsribe" action="#" method="post"> 
						<input type="text" name="name" placeholder="Your Name" required="">
						<input type="email" name="email" placeholder="your Email" required="">
						<input type="submit" value="SignUp"> 
						<div class="clearfix"></div>
					</form>
				</div> 
			</div>
		</div>
	</div>
	<!-- //subscribe --> 
	<script src="js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>

</body>
</html>