<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>

    <script>window.location.href = '<?php echo e(route("login")); ?>';</script>

<?php endif; ?>

<?php echo $__env->make('partials.view Table_partial', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
    <div class="col-md-10 col-md-offset-1">

            <?php echo $__env->make('partials.monthchart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
</div>
    <br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>