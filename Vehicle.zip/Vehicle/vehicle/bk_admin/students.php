<?php
include_once '../class/pdo.php';
$select_accounts = select('newaccount')->order('id DESC')->limit(8)->results();    
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>View All </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="E-Banking Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">
<link href="css/dk-custom.css" rel="stylesheet">  
<link href="css/font-awesome.css" rel="stylesheet">   <!-- font-awesome icons --> 
<!-- //Custom Theme files -->  
<!-- js --> 
	<script src="js/jquery-2.2.3.min.js"></script>
<!-- web-fonts -->
<link href="//fonts.googleapis.com/css?family=Secular+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
<!-- //web-fonts --> 

</head>
<body> 
	<!-- header -->	
	<!-- //header -->  
	<!-- banner -->
        <div class="inner-banner">
		<div class="header-nav"><!-- header-three --> 	
			<nav class="navbar navbar-default">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						Menu 
					</button> 
				</div>
				<!-- top-nav -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
                            <li><a href="students.php" class="scroll">View All</a></li>
					
						<li><a href="logout.php" class="scroll">Logout</a></li>
					</ul> 
					<div class="clearfix"> </div>	
				</div>
			</nav>    
		</div>
		<!-- banner-text -->
		<!-- banner -->
	</div>	
	<!-- contact -->
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="contact_wthreerow agileits-w3layouts">
			<h4 align="center">List Of All Registered Vehicle</h4>
                            <div class="col-md-10 col-md-offset-1">
							<?php
            foreach($select_accounts AS $key=>$value){
                
            ?>
                                <div class="thumbnail rounded-none">
                                    <div class="media innerAll">
                                     
                                        <div class="media-body innerL">TYPE OF VEHICLE
                                            <a href="services.php?id=<?php echo $select_accounts[$key]['id']; ?>"><h3 class="fine_text"><?php echo $select_accounts[$key]['password']; ?></h3></a>
                                            <span><?php</span><br/>
                                            <span>NAME: </span>
                                            <span><?php echo $select_accounts[$key]['username']; ?></span><br/>
                                          
											<span>TYPE OF USAGE: </span>
                                            <span><?php echo $select_accounts[$key]['name']; ?></span><br/>
											<span>VEHICLE NUMBER: </span>
                                            <span><?php echo $select_accounts[$key]['acbal']; ?></span><br/>
											<span>PERMANENT ADDRESS: </span>
                                            <span><?php echo $select_accounts[$key]['accbearername']; ?></span>
                                        </div>
                                        <span class="pull-right">
                                            <a href="delete.php?id=<?php echo $select_accounts[$key]['id']; ?>" class="btn btn-primary rounded-none">Delete</a>
                                        </span>
                                    </div>
                                </div>
								
			<?php }
			?>
                              
                            </div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //contact --> 

<!--footer-->
<div class="agile-footer w3ls-section">
	<div class="container">
	
		<div class="col-md-6 col-md-offset-3 text-center agileinfo-sub">
			<h6 style="margin-bottom: 10px">Click the link below to start the subscription service</h6>
			<button type="button" class="btn btn-primary" href="#" data-toggle="modal" data-target="#myModal1">subscribe</button>
		</div>
		<div class="clearfix"></div>
     </div>
</div>	 
<div class="w3_agile-copyright text-center">
    <p class="text-center">© 2017 COMPUTERISED VEHICLE LICENSE REGISTRATION SYSTEM</p>
</div>
<!--//footer-->	
	<!-- subscribe -->
	<div class="modal bnr-modal fade" id="transfer" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
                                    <img src="images/logo.png" alt="logo" width="150"/>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
                                    <p class="fine_text font-weight-6">CAREFULLY PROVIDE THE DETAILS BELOW AND CLICK CONTINUE TO PROCESS.</p>
					<form class=" wthree-subsribe" action="#" method="post"> 
                                            <input type="text" name="bankname" placeholder="Beneficiary Bank Name" required="" style="margin-bottom: 10px">
						<input type="text" name="accountname" placeholder="Beneficiary Account Name" required="" style="margin-bottom: 10px">
						<input type="text" name="accountnumber" placeholder="Beneficiary Account Number" required="" style="margin-bottom: 10px">
                                                <button type="button" class="btn btn-primary center-block" href="#" data-toggle="modal" data-target="#myModal1">Continue</button>
						<div class="clearfix"></div>
					</form>
				</div> 
			</div>
		</div>
	</div>
	<div class="modal bnr-modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<img src="images/logo.png" alt="logo" width="150"/>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
                                    <h2 style="color: #e51c23;" class="text-center">Almost There!</h2>
                                    <h5 style="" class="text-center">Please contact customer care agent for a transfer confirmation security code</h5>
					<form class=" wthree-subsribe" action="#" method="post"> 
						<input type="text" name="secode" placeholder="Security Code" required="" style="margin-bottom: 10px">
						<input type="text" name="resecode" placeholder="Repeat Security Code" required="" style="margin-bottom: 10px">
                                                <button type="submit" class="center-block btn btn-primary">Finish</button>
						<div class="clearfix"></div>
					</form>
				</div> 
			</div>
		</div>
	</div>
	<!-- //subscribe --> 
	<script src="js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>

</body>
</html>