<?php

class crud
{
    /** @var object $pdo Copy of PDO connection */
	private $db;
     /** @var object of the logged in user */
    private $user;
    /** @var string error msg */
    private $msg;
    /** @var int number of permitted wrong login attemps */
    private $permitedAttemps = 5;
	function __construct($DB_con)
	{
		$this->db = $DB_con;
	}
    
        /**
    * Register a new user account function
    * @param string $email User email.
    * @param string $fname User first name.
    * @param string $lname User last name.
    * @param string $pass User password.
    * @return boolean of success. 
    *for email valid test */
    
    public function registration($username,$phone,$password,$school,$email){
       // $pdo = $this->pdo;
        if($this->checkEmail($email)){
            $this->msg = 'This email is already taken.';
            return false;
        }
        /*if(!(isset($email) && isset($fname) && isset($lname) && isset($pass) && filter_var($email, FILTER_VALIDATE_EMAIL))){
            $this->msg = 'Inesrt all valid requered fields.';
            return false;
        }*/

        $pass = $this->hashPass($password);
        $verificationcode = $this->hashPass(date('Y-m-d H:i:s').$email);
        $stmt = $this->$db->prepare('INSERT INTO campus_market_users(id,username,phone,password1,school,verificationcode,verified,date,email,attempt,userrole,ban) VALUES (:id, :username, :phone, :password1, :school, :verificationcode, :verified, now(), :email, :attempt, :userrole, :ban)');        
        $stmt->bindParam(":username",$username);
			$stmt->bindparam(":phone",$phone);
			$stmt->bindparam(":password1",$new_password);
			$stmt->bindparam(":school",$school);
			$stmt->bindparam(":verificationcode",$verificationcode);
			$stmt->bindparam(":verified",$verified);
			$stmt->bindparam(":id",$id);
            $stmt->bindparam(":email",$email);
            $stmt->bindparam(":attempt");
            $stmt->bindparam(":userrole");
            $stmt->bindparam("ban");
        if($stmt->execute){
            if($this->sendEmail($email)){
                return true;
            }else{
                $this->msg = 'confirmation email sending has failed.';
                return false; 
            }
        }else{
            $this->msg = 'Inesrting a new user failed.';
            return false;
        }
    }
    
    
     /**
    * Check if email is already used function
    * @param string $email User email.
    * @return boolean of success.
    
    */
    
    private function checkEmail($email){
        //$pdo = $this->pdo;
        $stmt = $this->db->prepare('SELECT id FROM campus_market_users WHERE email = ? limit 1');
        $stmt->execute([$email]);
        if($stmt->rowCount() > 0){
            return true;
        }else{
            return false;
        }
    }
    
    
    /**
    * Email the confirmation code function
    * @param string $email User email.
    * @return boolean of success.
    */
    public function sendEmail($email){
        $stmt = $this->db->prepare('SELECT confirm_code FROM cmarket_user WHERE email = ? limit 1');
        $stmt->execute([$email]);
        $code = $stmt->fetch();

        $subject = 'Confirm your registration';
        $message = ' 
    <html>
    <head>
        <title>CAMPUS MARKET</title>
    </head>
    <body>
        <h1>Thank you for registering with Campus Market</h1>
        <table cellspacing="0" style="border: 2px dashed #FB4314; width: 300px; height: 200px;">
            <tr>
                <th>Click on the link to activate your Campus Market Account</td>
            </tr>
            <tr style="background-color: #e0e0e0;">
                <th>Email:</th><td>info@campusmarket.com.com</td>
            </tr>
            <tr>
                <th>Website:</th><td><a href="http://localhost/marketbase/activate.php?id='.base64_decode($code).'&email='.base64_decode($email).'">kd562ndnsd8sd87dsnmsnmdsddsmbnsd78sdsdjhsd78dh893jk8e7erjk2378823</a></td>
            </tr>
        </table>
    </body>
    </html>';
        // Set content-type header for sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // Additional headers
        $headers .= 'From: CampusMarket<info@campusmarket.com.ng>' . "\r\n";
      
        if(mail($email, $subject, $message, $headers)){
            return true;
        }else{
            return false;
        }
    }

    /**
    * Activate a login by a confirmation code and login function
    * @param string $email User email.
    * @param string $confCode Confirmation code.
    * @return boolean of success.
    */
    public function emailActivation($email,$confCode){
       // $pdo = $this->pdo;
        $stmt = $this->db->prepare('UPDATE cmarket_user SET confirmed = 1 WHERE email = ? and confirm_code = ?');
        $stmt->execute([$email,$confCode]);
        if($stmt->rowCount()>0){
            $stmt = $this->db->prepare('SELECT id, username, phone, email, attempts, roles FROM cmarket_user WHERE email = ? and confirmed = 1 limit 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            $this->user = $user;
           // session_regenerate_id();
            if(!empty($user['email'])){
            	$_SESSION['user']['id'] = $user['id'];
	            $_SESSION['user']['username'] = $user['username'];
	            $_SESSION['user']['phone'] = $user['phone'];
	            $_SESSION['user']['email'] = $user['email'];
	            $_SESSION['user']['attempts'] = $user['attempts'];
                    $_SESSION['user']['roles'] = $user['roles'];
	            return true;
            }else{
            	$this->msg = 'Account activitation failed.';
            	return false;
            }            
        }else{
            $this->msg = 'Account activitation failed.';
            return false;
        }
    }

    
     /**
    * Password hash function
    * @param string $password User password.
    * @return string $password Hashed password.
    */
    private function hashPass($pass){
        return password_hash($pass, PASSWORD_DEFAULT);
    }
    
	//functions to create new user 
	public function create_user($username,$phone,$password1,$school,$verificationcode,$verified)
	{
		try
		{
			$new_password = password_hash($password1, PASSWORD_DEFAULT);
			$stmt = $this->db->prepare("INSERT INTO campus_market_users(id,username,phone,password1,school,verificationcode,verified,date) VALUES(:id, :username, :phone, :password1, :school, :verificationcode, :verified, now())");
			$stmt->bindParam(":username",$username);
			$stmt->bindparam(":phone",$phone);
			$stmt->bindparam(":password1",$new_password);
			$stmt->bindparam(":school",$school);
			$stmt->bindparam(":verificationcode",$verificationcode);
			$stmt->bindparam(":verified",$verified);
			$stmt->bindparam(":id",$id);
			//$stmt->bindparam(":date",$date);
			$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	
	//function to create new product 
	
		public function create_product($product_id,$product_name,$school,$phone,$product_price,$product_category,$product_picture,$comment,$user_id,$verified,$trending,$pushup,$remove)
	{
		try
		{
			$stmt = $this->db->prepare("INSERT INTO campus_market_product(product_id,product_name,school,phone,product_price,product_category,product_picture,comment,verified,trending,user_id,pushup,views,remove,date) VALUES(:product_id, :product_name, :school, :phone, :product_price, :product_category, :product_picture, :comment, :verified, :trending, :user_id, :pushup, 1, :remove, now())");
			$stmt->bindparam(":product_id",$product_id);
			$stmt->bindparam(":product_name",$product_name);
			$stmt->bindparam(":school",$school);
			$stmt->bindparam(":phone",$phone);
			$stmt->bindparam(":product_price",$product_price);
			$stmt->bindparam(":product_category",$product_category);
			$stmt->bindparam(":product_picture",$product_picture);
			$stmt->bindparam(":comment",$comment);
			$stmt->bindparam(":verified",$verified);
			$stmt->bindparam(":trending",$trending);
			$stmt->bindparam(":user_id",$user_id);
			$stmt->bindparam(":pushup",$pushup);
			$stmt->bindparam(":remove",$remove);
			//$stmt->bindparam(":date",$date);
			$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	
	//function to automatically update users information during first time sale
	
	public function update_user($phone,$username1,$password1,$email)
	{
		try
		{
			$new_password = password_hash($password1, PASSWORD_DEFAULT);
			$stmt=$this->db->prepare("UPDATE campus_market_users SET username=:username1, 
		                                               password1=:password1, 
													   email=:email
													   WHERE phone=:phone ");
			$stmt->bindparam(":username1",$username1);
			$stmt->bindparam(":password1",$new_password);
			$stmt->bindparam(":email",$email);
			$stmt->bindparam(":phone",$phone);
			if($stmt->execute()){
            if($this->sendConfirmationEmail($email)){
                return true;
            }else{
                $this->msg = 'confirmation email sending has failed.';
                return false; 
            }
        }else{
            $this->msg = 'updating a new user failed.';
            return false;
        }
			
				
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
	}
    
	//function to update the product (user id) and the restore_error_handler
		public function update_product($phone,$user_id)
			{
				try
				{
					$stmt=$this->db->prepare("UPDATE campus_market_product SET user_id=:user_id WHERE phone=:phone");
					$stmt->bindparam(":user_id",$user_id);
					$stmt->bindparam(":phone",$phone);
					$stmt->execute();
					
					return true;
				}catch(PDOException $e)
				{
					echo $e->getMessage();
					return false;
				}
			
			}
			
		
			
	//getting a single user from the users table		
		public function get_id($phone)
	{
		$stmt = $this->db->prepare("SELECT * FROM campus_market_users WHERE phone=:phone");
		$stmt->execute(array(":phone"=>$phone));
		$editRow=$stmt->fetch(PDO::FETCH_ASSOC);
		return $editRow;
	}
	
/*	public function delete($id)
	{
		$stmt = $this->db->prepare("DELETE FROM tbl_users WHERE id=:id");
		$stmt->bindparam(":id",$id);
		$stmt->execute();
		return true;
	}
    
      /**
    * Return the logged in user.
    * @return user array data
    */
    public function getUser(){
        return $this->user;
    }
        
   public function categoryDataview($query){
		$stmt = $this->db->prepare($query);
		$stmt->execute();
	
		if($stmt->rowCount()>0)
		{
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
			{
				?>
		    <div class="thumbnail padding-none hover-shadowed hover-transparent">
                        <div class="thumbnail rounded-none margin-bottom-none border-none border-bottom">
                            <div class="media innerAll">
                               <a href="read_campus_news.html"><img src="upload/<?php echo $row['image']; ?>" class="media-object pull-left border-all hover-transparent" width="150" /></a>
                               <div class="media-body innerLR">
                                   <a href="read_campus_news.html" class="text-dark fine-text"><h4 class="margin-top-none fine-text font-weight-6"><?php echo$row['topic']; ?></h4></a>
                                   <a href="read_campus_news.html" class="text-dark fine-text font-size-16"><?php echo security($row['body']); ?></a>
                               </div>
                            </div>
                       </div>
                        <div class=" bg-gray innerLR">
                            <div class="media">
                                <span class=" innerLR half h6 margin-none text-muted border-right"><span class="innerR half">200</span>Views</span>
                                <span class=" innerLR half h6 margin-none text-muted border-right"><span class="innerR half">50</span>Comments</span>
                                <span class=" innerLR half h6 margin-none text-muted border-right"><span class="innerR half"><i class="glyphicon glyphicon-calendar"></i></span>20 : 10 : 2017</span>
                                <span class=" innerLR half h6 margin-none text-muted border-right"><span class="innerR half"><i class="glyphicon glyphicon-time"></i></span>09 : 45 : am</span>
                            </div>
                        </div> 
                    </div>
                                                                       
		<?php										
			}
		}
		else
		{
			?>
            <tr>
            <td>Nothing here...</td>
            </tr>
            <?php
		}
		
	}
        
        
        
         public function categoryDataviewmobile($query){
		$stmt = $this->db->prepare($query);
		$stmt->execute();
	
		if($stmt->rowCount()>0)
		{
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
			{
				?>
				                  
            
                                                                <!--Item -->
                                                        <div class="media margin-none innerAll border-bottom bg-white border-all">
                                                            <a href="product.php?id=<?php echo base64_encode($row['id']); ?>" class="pull-left">
                                                                <img src="picture_upload/<?php echo $row['picture']; ?>" width="100" class="media-object img-responsive">
                                                            </a>
                                                              <a href="product.php?id=<?php echo base64_encode($row['id']); ?>" class="pull-left">
                                                            <div class="media-body padding-none ">
                                                                <h3 class="fine_text margin-top-5 font-size-12" style="margin-bottom: 0px;"><?php echo $row['name']; ?></h3>
                                                                <h3 class="fine_text margin-top-5 font-size-12" style="margin-bottom: 0px;"><del>₦</del><?php echo $row['price']; ?></h3>
                                                                <span class="thumbnail text-gray fine_text margin-bottom-none text-center"><?php echo $row['phone']; ?></span>
                                                            </div>
                                                              </a>
                                                        </div>
                                                        <!--/Item -->
                                                                       
		<?php										
			}
		}
		else
		{
			?>
            <tr>
            <td>Nothing here...</td>
            </tr>
            <?php
		}
		
	}
    
	
	/* paging */
	
	public function dataview($query)
	{
		$stmt = $this->db->prepare($query);
		$stmt->execute();
	
		if($stmt->rowCount()>0)
		{
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
			{
				?>
			
				 <div class="media margin-none innerAll border-bottom bg-white border-all">
                                                    <a href="product.html" class="pull-left">
                                                        <img src="picture_upload/<?php echo $row['product_picture'];?>" width="100" class="media-object img-responsive">
                                                    </a>
                                                    <div class="media-body innerAll padding-none ">
                                                        <div class="row">
                                                            <div class="col-sm-12">
                                                                <div class="media-body innerTB">
                                                                    <div class="pull-right innerT innerR text-muted">
                                                                        <span class="btn btn-default btn-xs"><?php echo '#'.$row['product_price']; ?></span><br />
                                                                        <span class="btn btn-default btn-xs"><?php echo $row['phone']; ?></span>
                                                                        <a href="my_product.php?product=<?php echo $row['product_id'];?>" class="btn btn-default btn-xs">Buy</a>
                                                                    </div>
                                                                    <a href="my_product.php?product=<?php echo $row['product_id']; ?>" class="strong text-inverse fine_text font-size-25"><?php echo $row['product_name']; ?></a><br />
                                                                    <a href="#" class="fine_text"><?php echo $row['product_category']; ?>||</a>
																	<a href="#" class="fine_text"><?php echo $row['school']; ?></a>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
		<?php										
			}
		}
		else
		{
			?>
            <tr>
            <td>No Category Selected</td>
            </tr>
            <?php
		}
		
	}
	
	public function paging($query,$records_per_page)
	{
		$starting_position=0;
		if(isset($_GET["page_no"]))
		{
			$starting_position=($_GET["page_no"]-1)*$records_per_page;
		}
		$query2=$query." limit $starting_position,$records_per_page";
		return $query2;
	}
	
	public function paginglink($query,$records_per_page)
	{
		
		$self = $_SERVER['PHP_SELF'];
		
		$stmt = $this->db->prepare($query);
		$stmt->execute();
		
		$total_no_of_records = $stmt->rowCount();
		
		if($total_no_of_records > 0)
		{
			?><ul class="pagination"><?php
			$total_no_of_pages=ceil($total_no_of_records/$records_per_page);
			$current_page=1;
			if(isset($_GET["page_no"]))
			{
				$current_page=$_GET["page_no"];
			}
			if($current_page!=1)
			{
				$previous =$current_page-1;
				echo "<li><a href='".$self."?page_no=1'>&laquo;</a></li>";
				echo "<li><a href='".$self."?page_no=".$previous."'>&raquo;</a></li>";
			}
			for($i=1;$i<=$total_no_of_pages;$i++)
			{
				if($i==$current_page)
				{
					echo "<li><a href='".$self."?page_no=".$i."' style='color:red;'>".$i."</a></li>";
				}
				else
				{
					echo "<li><a href='".$self."?page_no=".$i."'>".$i."</a></li>";
				}
			}
			if($current_page!=$total_no_of_pages)
			{
				$next=$current_page+1;
				echo "<li><a href='".$self."?page_no=".$next."'>&laquo;</a></li>";
				echo "<li><a href='".$self."?page_no=".$total_no_of_pages."'>&raquo;</a></li>";
			}
			?></ul><?php
		}
	}
	
	/* paging */
 
	
	public function login($username,$password1)
    {
       try
       {
          $stmt = $this->db->prepare("SELECT * FROM newaccount WHERE username=:username LIMIT 1");
          $stmt->execute(array(':username'=>$username));
          $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
          if($stmt->rowCount() > 0)
          {
             if($password1== $userRow['password'])
             {
                    $_SESSION['user']['id'] = $userRow['id'];
	            $_SESSION['user']['username'] = $userRow['username'];
	            /*$_SESSION['user']['phone'] = $userRow['phone'];
	            $_SESSION['user']['email'] = $userRow['email'];
	            $_SESSION['user']['attempts'] = $userRow['attempts'];
                    $_SESSION['user']['roles'] = $userRow['roles'];*/
				
                return true;
             }
             else
             {
                return false;
             }
          }
       }
       catch(PDOException $e)
       {
           echo $e->getMessage();
       }
   }
   
   public function is_loggedin()
   {
      if(isset($_SESSION['user']['id']))
      {
         return true;
      }
   }
 
   public function redirect($url)
   {
       header("Location: $url");
   }
 
   public function logout()
   {
        session_destroy();
        unset($_SESSION['user']['id']);
        unset($_SESSION['user']['username']);
        unset($_SESSION['user']['phone']);
        unset($_SESSION['user']['email']);
        return true;
   }
   
     /**
    * Register a wrong login attemp function
    * @param string $email User email.
    * @return void.
    */
    private function registerWrongLoginAttemp($email){
        //$pdo = $this->pdo;
        $stmt = $this->db->prepare('UPDATE cmarket_users SET wrong_logins = wrong_logins + 1 WHERE email = ?');
        $stmt->execute([$email]);
    }
    
    
    	//function to update the number of views the restore_error_handler
		public function update_views($product_id,$views)
			{
				try
				{
					$stmt=$this->db->prepare("UPDATE cmarket_product SET views=:views WHERE id=:product_id");
					$stmt->bindparam(":views",$views);
					$stmt->bindparam(":product_id",$product_id);
					$stmt->execute();
					
					return true;
				}catch(PDOException $e)
				{
					echo $e->getMessage();
					return false;
				}
			
			}
			
}
