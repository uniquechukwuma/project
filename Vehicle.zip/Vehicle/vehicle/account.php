<?php
include 'class/pdo.php';
require_once("class/dbconfig.php");
if($crud->is_loggedin()==FALSE){
    header('location:index.html');
}
//require_once("class/dbconfig.php");
$userid = $_SESSION['user']['id'];
$me = find('newaccount',$userid);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Profile | Information system</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="E-Banking Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">
<link href="css/dk-custom.css" rel="stylesheet">  
<link href="css/font-awesome.css" rel="stylesheet">   <!-- font-awesome icons --> 
<!-- //Custom Theme files -->  
<!-- js --> 
	<script src="js/jquery-2.2.3.min.js"></script>
<!-- web-fonts -->
<link href="//fonts.googleapis.com/css?family=Secular+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
<!-- //web-fonts --> 

</head>
<body> 
	<!-- header -->
	<div class="headerw3-agile"> 
		<div class="header-w3mdl"><!-- header-two --> 
			<div class="container"> 
				<div class="agileits-logo navbar-left">
					<h1><a href="index.html"><img src="images/logo.png" alt="logo"/></a></h1> 
				</div> 
				<div class="agileits-hdright nav navbar-nav">
					<div class="header-w3top"><!-- header-top --> 
						<ul class="w3l-nav-top">
							<li><i class="fa fa-phone"></i><span><?php echo $me['phone']; ?></span></li> 
							<li><a href="mailto:example@mail.com"><i class="fa fa-envelope-o"></i> <span><?php echo $me['email']; ?></span></a></li>
							<li><i class="fa fa-user"></i> <span> <?php echo 'Welcome '. $me['username']; ?></span></li>
							<li><a href="logout.php"><i class="fa fa-user-times"></i> <span> Logout</span></a></li>
						</ul>
						<div class="clearfix"> </div> 	 
					</div>
					<!--div class="agile_social_banner">
						<ul class="agileits_social_list">
							<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
							<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
						</ul>
					</div-->  

				</div>
				<div class="clearfix"> </div> 
			</div>	
		</div>	
	</div>	
	<!-- //header -->  
	<!-- banner -->
        <div class="inner-banner">
		<div class="header-nav"><!-- header-three --> 	
			<nav class="navbar navbar-default">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						Menu 
					</button> 
				</div>
				<!-- top-nav -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					
						<li><a href="index.html" class="active">Home</a></li>

						<li><a href="contact.html" class="scroll">Contact Us</a></li>
					 
					</ul>  
					<div class="clearfix"> </div>	
				</div>
			</nav>    
		</div>
		<!-- banner-text -->
		<!-- banner -->
	</div>	
	<!-- contact -->
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="contact_wthreerow agileits-w3layouts">
                            <div class="col-md-10 col-md-offset-1">
                                <div class="thumbnail rounded-none">
                                     <!--  <div class="media innerAll">
                                        <img src="upload/<?php echo $me['pics']; ?>" class="media-object pull-left" height="150"/>
                                    <div class="media-body">
                                            <span class="pull-right" style="margin-right: 100px;">
                                                <span class="fine_text font-weight-6">
                                                    Balance
                                                </span><br/>
                                                <span class="fine_text font-weight-3">
                                                    $<?php echo $me['acbal']; ?>
                                                </span><br/>
                                                <button type="button" class="btn btn-primary margin-top-10" href="#" data-toggle="modal" data-target="#transfer">Transfer</button>
                                            </span>
                                        </div> 
                                    </div> -->
                                    <div class="innerAll">
                                        <div class="table">
                                            <h2 class="fine_text innerB"><?php echo $me['username']; ?> VEHICLE'S REGISTRATION INFORMATION</h2>
                                            <table class="table table-responsive table-bordered table-striped">
											<tr>
                                                    <td>Name</td>
                                                    <td><?php echo $me['username']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>TYPE</td>
                                                    <td><?php echo $me['name']; ?></td>
                                                </tr>
												    <tr>
                                                    <td>PLATE NUMBER</td>
                                                    <td><?php echo $me['acctype']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>VEHICLE </td>
                                                    <td><?php echo $me['password']; ?></td>
                                                </tr>
												
												  <tr>
                                                    <td>PERMANENT ADDRESS</td>
                                                    <td><?php echo $me['accbearername']; ?></td>
                                                </tr>
                                               <tr>
                                                    <td>ENGINE NUMBER</td>
                                                    <td><?php echo $me['acbal']; ?></td>
                                                </tr>
                                          
                                                <!--<tr>
                                                    <td> <button> Print </button></td>
                                                    <td>Congratulations</td>
                                                </tr> -->
                                              
                                                <tr>
                                                    <!--<td><a href="submit_assign.php">Document the proceedings</a></td>-->
                                                    <td></td>
                                                </tr>
                                                
                                               
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div> 
	<!-- //contact --> 

<!--footer-->
<div class="agile-footer w3ls-section">
	<div class="container">
		<!--div class="col-md-7 list-footer">
		  <ul class="footer-nav">
				<li><a  href="index.html">Home</a></li>
				<li><a  href="about.html">About</a></li>
				<li><a  href="services.html">Services</a></li>
				<li><a href="gallery.html">Gallery</a></li>
				<li><a href="contact.html">Contact Us</a></li>
		  </ul>
		  <p>Vivamus sed porttitor felis. Pellentesque habitant morbi tristique senectus et netus et ctetur adipiscing elit. Cras rutrum iaculis</p>
		</div-->
		<div class="col-md-6 col-md-offset-3 text-center agileinfo-sub">
			<h6 style="margin-bottom: 10px">Click the link below to start the subscription service</h6>
			<button type="button" class="btn btn-primary" href="#" data-toggle="modal" data-target="#myModal1">subscribe</button>
		</div>
		<div class="clearfix"></div>
     </div>
</div>	 
<div class="w3_agile-copyright text-center">
    <p class="text-center">© 2017 CENSUS MANAGEMENT SYSTEM</p>
</div>
<!--//footer-->	
	<!-- subscribe -->
	<div class="modal bnr-modal fade" id="transfer" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
                                    <img src="images/logo.png" alt="logo" width="150"/>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
                                    <p class="fine_text font-weight-6">CAREFULLY PROVIDE THE DETAILS BELOW AND CLICK CONTINUE TO PROCESS.</p>
					<form class=" wthree-subsribe" action="#" method="post"> 
                                            <input type="text" name="bankname" placeholder="Beneficiary Bank Name" required="" style="margin-bottom: 10px">
						<input type="text" name="accountname" placeholder="Beneficiary Account Name" required="" style="margin-bottom: 10px">
						<input type="text" name="accountnumber" placeholder="Beneficiary Account Number" required="" style="margin-bottom: 10px">
                                                <button type="button" class="btn btn-primary center-block" href="#" data-toggle="modal" data-target="#myModal1">Continue</button>
						<div class="clearfix"></div>
					</form>
				</div> 
			</div>
		</div>
	</div>
	<div class="modal bnr-modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<img src="images/logo.png" alt="logo" width="150"/>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
                                    <h2 style="color: #e51c23;" class="text-center">Almost There!</h2>
                                    <h5 style="" class="text-center">Please contact customer care agent for a transfer confirmation security code</h5>
					<form class=" wthree-subsribe" action="#" method="post"> 
						<input type="text" name="secode" placeholder="Security Code" required="" style="margin-bottom: 10px">
						<input type="text" name="resecode" placeholder="Repeat Security Code" required="" style="margin-bottom: 10px">
                                                <button type="submit" class="center-block btn btn-primary">Finish</button>
						<div class="clearfix"></div>
					</form>
				</div> 
			</div>
		</div>
	</div>
	<!-- //subscribe --> 
	<script src="js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>

</body>
</html>