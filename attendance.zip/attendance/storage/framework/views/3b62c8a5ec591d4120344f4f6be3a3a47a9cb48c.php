<?php $__env->startSection('content'); ?>
    <?php if(Auth::guest()): ?>

        <script>window.location.href = '<?php echo e(route("login")); ?>';</script>

    <?php endif; ?>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">

          <?php echo $chart->render(); ?>


            <div class="row">
                <div class="col-md-10 col-md-offset-1">

                    <div class="col-md-10 col-md-offset-0">
                        <button   id="1" > <b>&lArr;</b> </button>
                    </div>

                    <div class="col-md-2 col-md-offset-0">
                        <a   id="2" > <b>&rArr;</b> </a>
                    </div>

                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>