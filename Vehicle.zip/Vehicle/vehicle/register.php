<?php
 //error_reporting(E_ALL & ~E_NOTICE);
include_once 'class/pdo.php';
if(isset($_POST['create_btn'])){
$username = security($_POST['accountusername']);
$password = security($_POST['accountpassword']);
$acctname = security($_POST['accountname']);
$acctype = security($_POST['acctype']);
$accountballance = security($_POST['address']);
$bearer = security($_POST['abname']); //date('Y-m-d H:i:s');
$email = security($_POST['email']);

$phone = security($_POST['phone']);
/*
$lastw = security($_POST['lastw']);
$lastd = security($_POST['lastd']); 
$pics = security($_FILES['pic']['tmp_name']);

$pics = (rand(0,20000).basename($_FILES['pic']['name']));
					
$upload = 'upload/'.$pics;
if(move_uploaded_file($_FILES['pic']["tmp_name"],$upload)){
$insert = insert('newaccount')->values(array('id'=>'', 'username'=>$username, 'password'=>$password, 'name'=>$acctname, 'acctype'=>$acctype, 'acbal'=>$accountballance, 'accbearername'=>$bearer, 'email'=>$email, 'phone'=>$phone, 'lastwithdraw'=>$lastw, 'lastpaid'=>$lastd,'pics'=>$pics));
*/
$insert = insert('newaccount')->values(array('id'=>'', 'username'=>$username, 'password'=>$password, 'name'=>$acctname, 'acctype'=>$acctype, 'acbal'=>$accountballance, 'accbearername'=>$bearer, 'email'=>$email, 'phone'=>$phone, 'lastwithdraw'=>'', 'lastpaid'=>'','pics'=>'now()'));
echo "<script>alert('New Vehicle has been registered')</script>";
//}
}
include 'header.html';
?>

	<!-- banner -->
        <div class="banner inner-banner" style="background: url(images/register.png)no-repeat center center;">
		<div class="header-nav"><!-- header-three --> 	
			<nav class="navbar navbar-default">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						Menu 
					</button> 
				</div>
				<!-- top-nav -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li><a href="index.html" class="active">Home</a></li>
						   
						<li><a href="register.php" class="scroll">New</a></li>    
                        <li><a href="login.php" class="scroll">Login</a></li>	
						<li><a href="contact.html" class="scroll">Contact Us</a></li>
					</ul>  
					<div class="clearfix"> </div>	
				</div>
			</nav>     
		</div>
		<!-- banner-text -->
		<!-- banner -->
	</div>	
		<!-- banner -->
	</div>
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
				<h2 class="h3-w3l">REGISTER NEW VEHICLE</h2> 
			</div>
			<div class="contact_wthreerow agileits-w3layouts">
                            <div class="col-md-6 col-md-offset-3">
                                <form method="post" enctype="multipart/form-data" name="form1">
                                    <div class="text-danger text-center">Error Message</div>
                                    <div class="form-group">
                                        <label for="accountusername" class="font-weight-3 fine_text innerB">Full Name</label>
                                        <input type="text" class="form-control rounded-none" name="accountusername" placeholder="UserName" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="accountpassword" class="font-weight-3 fine_text innerB">TYPE OF VEHICLE</label>
                                        <input type="text" class="form-control rounded-none" name="accountpassword" placeholder="Account Password" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="accountname" class="font-weight-3 fine_text innerB">PRIVATE/COMMERCIAL</label>
                                       <input type="text" class="form-control rounded-none" name="accountname" placeholder="Product" required/>
										
                                    </div>
                                    <div class="form-group">
                                        <label for="acctype" class="font-weight-3 fine_text innerB">PLATE NUMBER</label>
                                        <input type="text" class="form-control rounded-none" name="acctype" placeholder="quantity" required/>
                                    </div>
                                 
					
								 <div class="form-group">
                                        <label for="address" class="font-weight-3 fine_text innerB">ENGINE NUMBER</label>
                                        <input type="text" class="form-control rounded-none" name="address" placeholder="Residential Address"/>
                                    </div>
											
                                   <div class="form-group">
                                        <label for="abname" class="font-weight-3 fine_text innerB">RESIDENTIAL ADDRESS</label>
                                        <input type="text" class="form-control rounded-none" name="abname" placeholder="Account Bearer Name" required/>
                                    </div>
									 
                                    <div class="form-group">
                                        <label for="email" class="font-weight-3 fine_text innerB">PERMANENT ADDRESS</label>
                                        <input type="text" class="form-control rounded-none" name="email" placeholder="Email" required/>
                                    </div>
									
                                    <div class="form-group">
                                        <label for="phone" class="font-weight-3 fine_text innerB">SEX</label>
                                        <input type="text" class="form-control rounded-none" name="phone" placeholder="Phone" required/>
                                    </div>
									<!--
                                  <div class="form-group">
                                        <label for="lastw" class="font-weight-3 fine_text innerB">Contact Address</label>
                                        <input type="text" class="form-control rounded-none" name="lastw" placeholder="Home Address" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="lastd" class="font-weight-3 fine_text innerB">Sum Played</label>
                                        <input type="text" class="form-control rounded-none" name="lastd" placeholder="Last Amount Deposited" required/>
                                    </div> 
                            
                                    <div class="form-group">
                                        <label for="bday" class="font-weight-3 fine_text innerB">Select Passport</label>
                                        <input type="file" class="form-control rounded-none" name="pic" required/>
                                    </div> -->
									
                                    <button type="submit" name="create_btn" class="btn btn-primary rounded-none center-block">Go</button>
                                </form>
                            </div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //contact --> 

<!--footer-->
<div class="agile-footer w3ls-section">
	<div class="container">
		<!--div class="col-md-7 list-footer">
		  <ul class="footer-nav">
				<li><a  href="index.html">Home</a></li>
				<li><a  href="about.html">About</a></li>
				<li><a  href="services.html">Services</a></li>
				<li><a href="gallery.html">Gallery</a></li>
				<li><a href="contact.html">Contact Us</a></li>
		  </ul>
		  <p>Vivamus sed porttitor felis. Pellentesque habitant morbi tristique senectus et netus et ctetur adipiscing elit. Cras rutrum iaculis</p>
		</div-->
		<div class="clearfix"></div>
     </div>
</div>	 
<div class="w3_agile-copyright text-center">
    <p class="text-center">© 2017 COMPUTERISED VEHICLE LICENSE REGISTRATION SYSTEM</p>
</div>
<!--//footer-->	
	<!-- subscribe -->
	<div class="modal bnr-modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<img src="images/logo.png" alt="logo"/>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
					<p>Star Merchant email newsletter provides subscribers with helpful articles on important issues in the banking industry, as well as news about events and more! To sign up for the newsletter, fill the below form.</p>
					<form class=" wthree-subsribe" action="#" method="post"> 
						<input type="text" name="name" placeholder="Your Name" required="">
						<input type="email" name="email" placeholder="your Email" required="">
						<input type="submit" value="SignUp"> 
						<div class="clearfix"></div>
					</form>
				</div> 
			</div>
		</div>
	</div>
	<!-- //subscribe --> 
	<script src="js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>

</body>
</html>