<?php
 //error_reporting(E_ALL & ~E_NOTICE);
include_once 'class/pdo.php';
require_once("class/dbconfig.php");
if($crud->is_loggedin()==FALSE){
    header('location:login.php');
}
$userid = $_SESSION['user']['id'];
$me = find('newaccount',$userid);
$error = "";
function freeRTE_Preload($content) {
	// Strip newline characters.
	$content = str_replace(chr(10), " ", $content);
	$content = str_replace(chr(13), " ", $content);
	// Replace single quotes.
	$content = str_replace(chr(145), chr(39), $content);
	$content = str_replace(chr(146), chr(39), $content);
	// Return the result.
	return addslashes($content);
	}
if(isset($_POST['create_btn'])){
	
		if(!empty($_POST['accountusername']))
		{
			if(strip_tags($_POST['freeRTE_content'])!='')
			{
	
$username = security($_POST['accountusername']);
$password = security($_POST['freeRTE_content']);
//$acctname = security($_POST['accountname']);
//$acctype = security($_POST['acctype']);
//$accountballance = security($_POST['accountballance']);
//$bearer = security($_POST['abname']);
//$email = security($_POST['email']);
//$phone = security($_POST['phone']);
//$lastw = security($_POST['lastw']);
//$lastd = security($_POST['lastd']);
//$pics = security($_FILES['pic']['tmp_name']);

//$pics = (rand(0,20000).basename($_FILES['pic']['name']));
					
//$upload = 'upload/'.$pics;
//if(move_uploaded_file($_FILES['pic']["tmp_name"],$upload)){
update('newaccount')->values(array('lastwithdraw'=>$username, 'lastpaid'=>$password))->where('id ='.$userid);
//$insert = insert('newaccount')->values(array('id'=>'', 'username'=>$username, 'password'=>$password, 'name'=>$acctname, 'acctype'=>$acctype, 'acbal'=>'', 'accbearername'=>'', 'email'=>'', 'phone'=>'', 'lastwithdraw'=>'', 'lastpaid'=>'','pics'=>''));

echo "<script>alert('Assignment submitted')</script>";
//}
header('location:  account.php');
		}else{$error = "no empty field";}
		
		}else{$error = "no empty field";}
}
include 'header.html';
?>

	<!-- banner -->
        <div class="banner inner-banner" style="background: url(images/register.png)no-repeat center center;">
		<div class="header-nav"><!-- header-three --> 	
			<nav class="navbar navbar-default">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						Menu 
					</button> 
				</div>
				<!-- top-nav -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
							<li><a href="index.html" class="active">Home</a></li>
						   
						<li><a href="register.php" class="scroll">Register Court Case</a></li>    
                        <li><a href="login.php" class="scroll">Logout</a></li>	
						<li><a href="contact.html" class="scroll">Contact Us</a></li>
					</ul> 
					<div class="clearfix"> </div>	
				</div>
			</nav>    
		</div>
		<!-- banner-text -->
		<!-- banner -->
	</div>	
		<!-- banner -->
	</div>
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
				<h2 class="h3-w3l">Submit <?php echo $me['name'] ?> Court Proceedings</h2> 
			</div>
			<div class="contact_wthreerow agileits-w3layouts">
                            <div class="col-md-6 col-md-offset-3">
                                <form method="post" enctype="multipart/form-data" name="form1">
                                    <div class="text-danger text-center">Error Message</div>
                                    <div class="form-group">
                                        <label for="accountusername" class="font-weight-3 fine_text innerB">Judge Name</label>
                                        <input type="text" class="form-control rounded-none" name="accountusername" placeholder="UserName" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="accountpassword" class="font-weight-3 fine_text innerB">Proceedings: </label>
                                        
 <div class="ric">
   <!-- Include the Free Rich Text Editor Runtime -->
        <script src="richtext/js/richtext.js" type="text/javascript" language="javascript"></script>
        <!-- Include the Free Rich Text Editor Variables Page -->
        <script src="richtext/js/config.js"type="text/javascript" language="javascript"></script>
        <!-- Initialise the editor -->
        <script>
        initRTE('', 'example.css');
        </script>
</div>
                                    </div>
                                   <!-- <div class="form-group">
                                        <label for="accountname" class="font-weight-3 fine_text innerB">Reg no </label>
                                        <input type="text" class="form-control rounded-none" name="accountname" placeholder="Reg No" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="acctype" class="font-weight-3 fine_text innerB">Course </label>
                                        <input type="text" class="form-control rounded-none" name="acctype" placeholder="Course" required/>
                                    </div>
                                 
								
								 <div class="form-group">
                                        <label for="accountballance" class="font-weight-3 fine_text innerB">Account Ballance </label>
                                        <input type="number_format" class="form-control rounded-none" name="accountballance" placeholder="Account Ballance"/>
                                    </div>
                                    <div class="form-group">
                                        <label for="abname" class="font-weight-3 fine_text innerB">Account Bearer Name </label>
                                        <input type="text" class="form-control rounded-none" name="abname" placeholder="Account Bearer Name" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="email" class="font-weight-3 fine_text innerB">Email </label>
                                        <input type="email" class="form-control rounded-none" name="email" placeholder="Email" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone" class="font-weight-3 fine_text innerB">Phone </label>
                                        <input type="number" class="form-control rounded-none" name="phone" placeholder="Phone" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="lastw" class="font-weight-3 fine_text innerB">Last Withdrawal</label>
                                        <input type="number" class="form-control rounded-none" name="lastw" placeholder="Home Address" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="lastd" class="font-weight-3 fine_text innerB">Last Deposit</label>
                                        <input type="number" class="form-control rounded-none" name="lastd" placeholder="Last Amount Deposited" required/>
                                    </div>
                             
                                    <div class="form-group">
                                        <label for="bday" class="font-weight-3 fine_text innerB">Select Passport</label>
                                        <input type="file" class="form-control rounded-none" name="pic" required/>
                                    </div>-->
									
                                    <button type="submit" name="create_btn" class="btn btn-primary rounded-none center-block">Submit</button>
                                </form>
                            </div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //contact --> 

<!--footer-->
<div class="agile-footer w3ls-section">
	<div class="container">
		<!--div class="col-md-7 list-footer">
		  <ul class="footer-nav">
				<li><a  href="index.html">Home</a></li>
				<li><a  href="about.html">About</a></li>
				<li><a  href="services.html">Services</a></li>
				<li><a href="gallery.html">Gallery</a></li>
				<li><a href="contact.html">Contact Us</a></li>
		  </ul>
		  <p>Vivamus sed porttitor felis. Pellentesque habitant morbi tristique senectus et netus et ctetur adipiscing elit. Cras rutrum iaculis</p>
		</div-->
		<div class="clearfix"></div>
     </div>
</div>	 
<div class="w3_agile-copyright text-center">
    <p class="text-center">© 2017 Star Merchant</p>
</div>
<!--//footer-->	
	<!-- subscribe -->
	<div class="modal bnr-modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<img src="images/logo.png" alt="logo"/>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
					<p>Star Merchant email newsletter provides subscribers with helpful articles on important issues in the banking industry, as well as news about events and more! To sign up for the newsletter, fill the below form.</p>
					<form class=" wthree-subsribe" action="#" method="post"> 
						<input type="text" name="name" placeholder="Your Name" required="">
						<input type="email" name="email" placeholder="your Email" required="">
						<input type="submit" value="SignUp"> 
						<div class="clearfix"></div>
					</form>
				</div> 
			</div>
		</div>
	</div>
	<!-- //subscribe --> 
	<script src="js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>

</body>
</html>