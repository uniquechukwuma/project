<?php
include_once '../class/pdo.php';
if(isset($_GET['id'])){
	$id = security($_GET['id']);
	delete('newaccount',$id);
	header('location: index.php');
}   
?>
